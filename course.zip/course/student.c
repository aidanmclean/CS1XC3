#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 *
 * @file student.c
 * @author mcleaa15
 * @date 2022-04-12
 * @brief These are all the student-related functions.
 * 
 */

/**
 * @brief This function adds a grade to a student's record
 * 
 * @param student This is a parameter of a pointer to a type student
 * @param grade This is a parameter of type double
 */
void add_grade(Student* student, double grade)
{
  // Adds 1 to the number of grades
  student->num_grades++;
  // If that student was the first, allocates space for grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    // Reallocates the grades array to have space for another grade
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Adds the grade being added to the end of the array
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This is a function that returns the average of a student
 * 
 * @param student This is a parameter of a pointer of type student
 * @return double This returns a double value
 */
double average(Student* student)
{
  // If the student has no grades return 0
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Sums the student's grades
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Divides the sum by number of courses and returns mean average
  return total / ((double) student->num_grades);
}

/**
 * @brief This is a function that prints a student's name, ID, grades, and average. 
 * 
 * @param student This is a parameter of a pointer to type student
 */
void print_student(Student* student)
{
  // Prints student's name
  printf("Name: %s %s\n", student->first_name, student->last_name);
  // Prints student's ID
  printf("ID: %s\n", student->id);
  // Iterates through student's grades and prints them
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  // Prints student's average
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function generates a random student with a random name, ID, and grades
 * 
 * @param grades this is a parameter of type int that determines how many grades the student has 
 * @return Student* This is an output of type student
 */
Student* generate_random_student(int grades)
{
  // This is a list of possible first names
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // This is a list of possible last names
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // Allocates memory for a student
  Student *new_student = calloc(1, sizeof(Student));

  // Picks a random name for the student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Generates new student ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Generates random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // Returns the student
  return new_student;
}