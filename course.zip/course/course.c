#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 *
 * @file course.c
 * @author mcleaa15
 * @date 2022-04-12
 * @brief These are all the course-related functions.
 * 
 */


/**
 * @brief This is a function that enrolls a student in a course
 * 
 * @param course This is a parameter of a pointer to a type Course
 * @param student This is a parameter of a pointer to a type Student
 */
void enroll_student(Course *course, Student *student)
{
  // Adds 1 to the total students
  course->total_students++;
  // If that student was the first
  if (course->total_students == 1) 
  {
    // Allocates 1 student
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // Reallocates the list to include 1 more student
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Adds the new student to the end of the array
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This is a function that, when given an input of type Course, 
 * it prints out the name and course code, along with the total students. It then
 * prints a divider and repeatedly calls the print_student function in a loop for every student in the list.
 * 
 * @param course This is a parameter of a pointer to type Course
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function returns the student in a course with the highest average
 * 
 * @param course This is a parameter of a pointer to a type Course 
 * @return Student* This is a return variable of a pointer to a type Student
 */
Student* top_student(Course* course)
{
  // Returns Null if there are no students
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // Stores initial max average as the average of the first student
  double max_average = average(&course->students[0]);

  // Stores a pointer to the first student in the course
  Student *student = &course->students[0];
 
  // Iterates through the list of total students
  for (int i = 1; i < course->total_students; i++)
  {
    // Stores the average of the student
    student_average = average(&course->students[i]);
    // If the average is the highest, stores it and remembers the student
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  // Returns student with highest average
  return student;
}

/**
 * @brief returns a list of all passing students in the course
 * 
 * @param course This is a parameter of a pointer to a type course
 * @param total_passing this is a parameter to a pointer to type int
 * @return Student* This is a return of type array of type Student
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Iterates through the students in a course
  for (int i = 0; i < course->total_students; i++) 
    // If the student has over 50 average, increases pass count
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocates the list with the size of type Student
  passing = calloc(count, sizeof(Student));


  int j = 0;
  // Iterates through students in course
  for (int i = 0; i < course->total_students; i++)
  {
    // If student is passing
    if (average(&course->students[i]) >= 50)
    {
      // Stores the student in a list
      passing[j] = course->students[i];
      j++; 
    }
  }
  // Sets the total students passing to the count variable 
  *total_passing = count;

  // Returns students passing
  return passing;
}