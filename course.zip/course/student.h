/**
 * @brief This is a definition of a custom type Student. It contains two char arrays 50 long each 
 * to store first and last names, called first_name and last_name, respectively. It contains another 
 * char array 11 long that stores the course id called id, a list of doubles to store grades called grades,
 * and an int value called num_grades that stores the number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
