#include "student.h"
#include <stdbool.h>

/**
 * @brief This is a definition of a custom type Course. It contains
 * an array of chars 100 long called name, an array of chars 10 long called code,
 * a list of type Student called student, and an int to count the total students called total_students.
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


